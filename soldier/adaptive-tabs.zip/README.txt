A Pen created at CodePen.io. You can find this one at http://codepen.io/Lewitje/pen/doJRBX.

 Tabs that animate to the height of their content when switched.

// With bonus color switcher