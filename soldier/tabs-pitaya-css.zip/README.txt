A Pen created at CodePen.io. You can find this one at http://codepen.io/flkt-crnpio/pen/WxROwy.

 It's another experiment to make tabs without javascript. 

http://flkt.mx/pitaya/componentes.html#pestanias